20120319 Bruno RICHARD (bruno.richard@raisonance.com)

Bug report: Some symbols computation does not work right.

In .ld files, when some symbols are computed, their results when computed by LD look invalid.

This problem was not showing on GCC versions up to 4.5.2, and is present with 4.6.1.

To show the problem, use the following command line:
arm-none-eabi-ld.exe" -T test.ld main.o -o main.elf -Map main.map

Here is an excerpt of the linker file that shows the problem:
    _eidata1 = (_sidata +  _edata) - _sdata ;       /* 0x08000004 in map file */
    _eidata2 =  _sidata + (_edata  - _sdata);       /* 0x08000004 in map file */
    same = (_eidata1 == _eidata2) ? 0x1 : 0x0;      /* 0x08000000 in map file !!!*/

The "same" Symbol should be 1, not 0.